Python Pygame Scrabbles Simulator
Rules:
The traditional rules of Scrabbles have been slightly modified to make to game more challenging.
Each player gets an initial amount of 7 character tokens. The goal is to create as many words as possbile along
the 13X13 Game board.
Each character earns whoever placed it on the board a different amount of points, in any case its placing forms
a valid english word with other characters on the game board.
Players can form words with characters placed by other players (and with characters they've placed themselves).
In every turn every player can choose to either place a character token on the board, or withdraw a new token from
the token bank. Each player can hold up to 9 tokens at his disposal at any given moment.
The bank starts with 50 tokens. When the bank empties, the game is over - the player with most points wins.